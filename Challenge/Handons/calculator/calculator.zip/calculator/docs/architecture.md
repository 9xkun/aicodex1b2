Client <--> Server:
+ Client sends a request to the server (JS)
+ Server (NodeJS) Express WebServer receives the request