1. 2 possitive --> 200, ok calculation
2. 2 negative --> 200
3. So big, 9e100000000000000000 (validate)
